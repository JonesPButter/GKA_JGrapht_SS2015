package exceptions;

public class FalschesFileformatException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
