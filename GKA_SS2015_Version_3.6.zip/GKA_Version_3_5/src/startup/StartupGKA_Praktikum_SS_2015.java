package startup;

import werkzeuge.MainController;

public class StartupGKA_Praktikum_SS_2015
{

    public static void main(String[] args)
    {
        MainController visualizer = new MainController();
        visualizer.showUI();

    }

}
