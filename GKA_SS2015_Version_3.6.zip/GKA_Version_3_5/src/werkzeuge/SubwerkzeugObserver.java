package werkzeuge;

public interface SubwerkzeugObserver
{
    public void reagiereAufAenderung();
    
    public void reagiereAufAenderung(Object o);
}
